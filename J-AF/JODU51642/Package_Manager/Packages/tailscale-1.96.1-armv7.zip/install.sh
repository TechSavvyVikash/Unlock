#!/bin/sh
# Tailscale install.sh — yadav_patched Package Manager
# -------------------------------------------------------
# Install dir:  /data/yadavApp/tailscale/
# Binaries:     /data/yadavApp/tailscale/bin/tailscaled
#               /data/yadavApp/tailscale/bin/tailscale
# Symlinks:     /usr/bin/tailscale  → /data/yadavApp/tailscale/bin/tailscale
#               /usr/sbin/tailscaled → /data/yadavApp/tailscale/bin/tailscaled
# State:        /data/yadavApp/tailscale/state/tailscaled.state
# Socket:       /tmp/tailscaled.sock
# Service:      /etc/systemd/system/tailscaled.service

SELF_DIR="$(cd "$(dirname "$0")" && pwd)"
APP_DIR="/data/yadavApp/tailscale"
BIN_DIR="$APP_DIR/bin"
STATE_DIR="$APP_DIR/state"
TMP_DIR="$APP_DIR/tmp"
SERVICE_FILE="/etc/systemd/system/tailscaled.service"
IPK_URL="http://bin.entware.net/armv7sf-k3.2/tailscale_1.96.1-1_armv7-3.2.ipk"
IPK_FILE="$TMP_DIR/tailscale.ipk"

echo "=== Tailscale Installer ==="
echo "Install dir: $APP_DIR"

# ── Step 1: Create directories ──────────────────────────────────
mkdir -p "$BIN_DIR" "$STATE_DIR" "$TMP_DIR"

# ── Step 2: Install binaries ─────────────────────────────────────
if [ -f "$SELF_DIR/bin/tailscaled" ] && [ -f "$SELF_DIR/bin/tailscale" ]; then
    echo "Using bundled binaries..."
    cp "$SELF_DIR/bin/tailscaled" "$BIN_DIR/tailscaled"
    cp "$SELF_DIR/bin/tailscale"  "$BIN_DIR/tailscale"
else
    echo "Downloading tailscale from entware..."
    wget -q --timeout=60 --tries=2 "$IPK_URL" -O "$IPK_FILE" 2>&1
    if [ $? -ne 0 ] || [ ! -s "$IPK_FILE" ]; then
        echo "ERROR: Download failed"; exit 1
    fi
    echo "Extracting .ipk..."
    cd "$TMP_DIR"
    tar -xzf "$IPK_FILE" 2>/dev/null
    if [ ! -f "$TMP_DIR/data.tar.gz" ]; then
        echo "ERROR: data.tar.gz not found in .ipk"; exit 1
    fi
    tar -xzf "$TMP_DIR/data.tar.gz" -C "$TMP_DIR" 2>/dev/null
    TS_BIN=$(find "$TMP_DIR" -name "tailscaled" -type f | head -1)
    TS_CLI=$(find "$TMP_DIR" -name "tailscale"  -type f | grep -v "tailscaled" | head -1)
    if [ -z "$TS_BIN" ] || [ -z "$TS_CLI" ]; then
        echo "ERROR: Could not find tailscale binaries"; exit 1
    fi
    cp "$TS_BIN" "$BIN_DIR/tailscaled"
    cp "$TS_CLI" "$BIN_DIR/tailscale"
fi

chmod +x "$BIN_DIR/tailscaled" "$BIN_DIR/tailscale"
echo "Binaries installed: $BIN_DIR/"

# ── Step 3: Symlinks in /usr/bin and /usr/sbin ──────────────────
# Need remount rw since / is read-only
mount -o remount,rw / 2>/dev/null

ln -sf "$BIN_DIR/tailscale"  /usr/bin/tailscale
ln -sf "$BIN_DIR/tailscaled" /usr/sbin/tailscaled
echo "Symlinks created:"
echo "  /usr/bin/tailscale  → $BIN_DIR/tailscale"
echo "  /usr/sbin/tailscaled → $BIN_DIR/tailscaled"

# ── Step 4: Create systemd service ──────────────────────────────
mkdir -p /etc/systemd/system

cat > "$SERVICE_FILE" << 'SVCEOF'
[Unit]
Description=Tailscale Node Agent for YadavApp
After=network-pre.target syslog.target
Wants=network-pre.target

[Service]
Environment="LD_LIBRARY_PATH=/data/yadavApp/tailscale/bin:/data/opt/lib:/data/lib:/usr/lib"
RuntimeDirectory=tailscale
RuntimeDirectoryMode=0777
ExecStartPre=/data/yadavApp/tailscale/bin/tailscaled --cleanup
ExecStart=/data/yadavApp/tailscale/bin/tailscaled \
    --state=/data/yadavApp/tailscale/state/tailscaled.state \
    --socket=/tmp/tailscaled.sock
ExecStartPost=/bin/sh -c 'sleep 5; /data/yadavApp/tailscale/bin/tailscale --socket=/tmp/tailscaled.sock web --listen 0.0.0.0:8088 &'
StandardOutput=append:/data/yadavApp/tailscale/tailscaled.log
StandardError=append:/data/yadavApp/tailscale/tailscaled.log
Restart=on-failure
User=root

[Install]
WantedBy=multi-user.target
SVCEOF

echo "Service file created: $SERVICE_FILE"

# ── Step 5: Enable service ──────────────────────────────────────
systemctl daemon-reload 2>/dev/null
systemctl enable tailscaled 2>/dev/null
echo "tailscaled service enabled."

# ── Step 6: Remount ro ──────────────────────────────────────────
mount -o remount,ro / 2>/dev/null

# ── Step 7: Write version ───────────────────────────────────────
echo "1.96.1" > "$APP_DIR/version"

# ── Step 8: Write uninstall.sh ──────────────────────────────────
cat > "$APP_DIR/uninstall.sh" << 'UNEOF'
#!/bin/sh
APP_DIR="/data/yadavApp/tailscale"
SERVICE_FILE="/etc/systemd/system/tailscaled.service"

echo "Stopping tailscaled..."
systemctl stop tailscaled 2>/dev/null
systemctl disable tailscaled 2>/dev/null
killall tailscaled 2>/dev/null
sleep 1

echo "Removing symlinks and service..."
mount -o remount,rw / 2>/dev/null
rm -f /usr/bin/tailscale
rm -f /usr/sbin/tailscaled
rm -f "$SERVICE_FILE"
systemctl daemon-reload 2>/dev/null
mount -o remount,ro / 2>/dev/null

echo "Removing binaries..."
rm -rf "$APP_DIR/bin" "$APP_DIR/tmp"
rm -f "$APP_DIR/uninstall.sh"
# Keep state/ — auth token preserved for reinstall
echo "Tailscale uninstalled. Auth state preserved at $APP_DIR/state/"
exit 0
UNEOF
chmod +x "$APP_DIR/uninstall.sh"

# ── Step 9: Clean up temp ───────────────────────────────────────
rm -rf "$TMP_DIR"

echo ""
echo "=== Installation complete ==="
echo ""
echo "Start now:    systemctl start tailscaled"
echo "Auth:         tailscale --socket=/tmp/tailscaled.sock login"
echo "Status:       tailscale --socket=/tmp/tailscaled.sock status"
echo "Auto-start:   already enabled via systemd"
echo ""
exit 0
