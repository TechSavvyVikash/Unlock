# Tailscale for Jio 5G CPE (yadav_patched)

## Paths
- Binaries:  /data/yadavApp/tailscale/bin/
- State:     /data/yadavApp/tailscale/state/tailscaled.state
- Socket:    /tmp/tailscaled.sock
- Log:       /data/yadavApp/tailscale/tailscaled.log
- Boot:      /etc/init.post_boot.sh (auto-start after 2 min)

## Start manually
```
/data/yadavApp/tailscale/bin/tailscaled \
  --state=/data/yadavApp/tailscale/state/tailscaled.state \
  --socket=/tmp/tailscaled.sock \
  --tun=userspace-networking &

/data/yadavApp/tailscale/bin/tailscale \
  --socket=/tmp/tailscaled.sock up
```

## Status
```
/data/yadavApp/tailscale/bin/tailscale \
  --socket=/tmp/tailscaled.sock status
```

## Notes
- Uses userspace networking (--tun=userspace-networking) since kernel TUN
  module may not be available on SDX65
- State persists across reboots in /data/yadavApp/tailscale/state/
- Auto-start waits 120s after boot for network to be ready
