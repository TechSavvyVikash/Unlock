#!/bin/sh
exec /data/yadavApp/tailscale/uninstall.sh
